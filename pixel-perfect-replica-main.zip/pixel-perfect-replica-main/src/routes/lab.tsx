import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Minus, Plus, Redo2, RotateCcw, Save, Trash2, Undo2, Replace, FolderOpen } from "lucide-react";
import { toast } from "sonner";
import { PageHead } from "@/components/section";
import { DishPicker } from "@/components/DishPicker";
import { FlavorRadar, ScoreRing } from "@/components/charts";
import { NutritionDiff } from "@/components/analysis";
import { ChefZest } from "@/components/brand";
import { DishImage } from "@/components/dish";
import { ING, INGREDIENTS, RECIPE, SWAPS } from "@/lib/flavor/data";
import { applyFix, flavorOf, healthScore, lint, matchScore, nutritionOf } from "@/lib/flavor/engine";
import type { Fix, RecipeItem } from "@/lib/flavor/types";
import { actions, useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/lab")({
  validateSearch: (s: Record<string, unknown>): { dish?: string } => ({
    dish: typeof s.dish === "string" && RECIPE[s.dish]?.kind === "craving" ? s.dish : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Recipe Mutation Lab — FlavorLint" },
      { name: "description", content: "Add, reduce, remove or swap ingredients and watch flavor match and nutrition update live." },
      { property: "og:title", content: "Recipe Mutation Lab — FlavorLint" },
      { property: "og:description", content: "Experiment with a recipe and see what changed." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Lab,
});

interface Hist { stack: RecipeItem[][]; i: number }

function Lab() {
  const { dish = "butter-chicken" } = Route.useSearch();
  const nav = useNavigate({ from: "/lab" });
  const base = RECIPE[dish];
  const [h, setH] = useState<Hist>({ stack: [base.items], i: 0 });
  const [reaction, setReaction] = useState("Pick an ingredient and tweak it. I'll taste along.");
  const [addId, setAddId] = useState("");
  const [name, setName] = useState("");
  const [compare, setCompare] = useState<string[]>([]);
  const { experiments } = useAppState();

  useEffect(() => {
    setH({ stack: [base.items], i: 0 });
    setReaction(`Fresh ${base.name} on the bench. What shall we try?`);
  }, [base]);

  const items = h.stack[h.i];
  const bf = useMemo(() => flavorOf(base.items), [base]);
  const bn = useMemo(() => nutritionOf(base.items), [base]);
  const cf = flavorOf(items), cn_ = nutritionOf(items);
  const match = matchScore(bf, cf);
  const health = healthScore(cn_), baseHealth = healthScore(bn);
  const win = match >= 85 && health - baseHealth >= 15;
  const suggestions = useMemo(() => lint(items).filter((f) => f.fix), [items]);
  const mine = experiments.filter((e) => e.baseId === dish);

  const commit = (next: RecipeItem[], msg: string) => {
    setH((s) => ({ stack: [...s.stack.slice(0, s.i + 1), next], i: s.i + 1 }));
    const nf = flavorOf(next), nn = nutritionOf(next);
    const dm = matchScore(bf, nf) - match, dh = healthScore(nn) - health;
    setReaction(`${msg}. Match ${dm >= 0 ? "+" : ""}${dm}, nutrition ${dh >= 0 ? "+" : ""}${dh}.${dm < -5 ? " That shifted the taste quite a bit." : dh > 3 ? " Nice — lighter without losing much." : ""}`);
  };
  const fix = (f: Fix, msg: string) => commit(applyFix(items, f), msg);

  const addables = INGREDIENTS.filter((i) => !items.some((x) => x.ing === i.id));

  return (
    <div>
      <PageHead
        eyebrow="Signature experience"
        title={<>Recipe <span className="italic text-primary">Mutation</span> Lab</>}
        sub="Change one thing at a time. Every edit recalculates flavor match and nutrition from the ingredient list."
        action={<DishPicker value={dish} onChange={(d) => nav({ search: { dish: d } })} />}
      />

      <div className="grid gap-6 xl:grid-cols-[1.25fr_1fr]">
        <section className="panel overflow-hidden" aria-label="Ingredients">
          <div className="flex items-center gap-4 border-b p-4">
            <DishImage id={base.id} name={base.name} className="h-14 w-14 rounded-lg" />
            <div className="flex-1">
              <p className="eyebrow">Base · 1 serving</p>
              <h2 className="font-display text-2xl">{base.name}</h2>
            </div>
            <div className="flex gap-1.5">
              <button className="btn-line !px-3" aria-label="Undo" disabled={h.i === 0} onClick={() => setH((s) => ({ ...s, i: s.i - 1 }))}><Undo2 className="h-4 w-4" /></button>
              <button className="btn-line !px-3" aria-label="Redo" disabled={h.i >= h.stack.length - 1} onClick={() => setH((s) => ({ ...s, i: s.i + 1 }))}><Redo2 className="h-4 w-4" /></button>
              <button className="btn-line !px-3" aria-label="Reset to original" disabled={h.stack.length === 1} onClick={() => { setH({ stack: [base.items], i: 0 }); setReaction("Back to the original. Clean slate."); }}><RotateCcw className="h-4 w-4" /></button>
            </div>
          </div>

          <ul className="divide-y">
            {items.map((it) => {
              const ing = ING[it.ing];
              const orig = base.items.find((b) => b.ing === it.ing);
              const changed = !orig ? "added" : orig.grams !== it.grams ? "changed" : null;
              const swaps = SWAPS[it.ing] ?? [];
              return (
                <li key={it.ing} className={cn("grid grid-cols-[1fr_auto] items-center gap-3 px-4 py-2.5 animate-rise sm:grid-cols-[1fr_auto_auto]", changed && "bg-primary/5")}>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{ing.name} {changed && <span className="tag-lime ml-1">{changed}</span>}</p>
                    <p className="text-xs text-muted-foreground">{ing.group}{orig && orig.grams !== it.grams ? ` · was ${orig.grams} g` : ""}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button className="btn-line !p-1.5" aria-label={`Reduce ${ing.name}`} onClick={() => fix({ kind: "scale", ing: it.ing, factor: 0.75 }, `Reduced ${ing.name}`)}><Minus className="h-3.5 w-3.5" /></button>
                    <label className="sr-only" htmlFor={`g-${it.ing}`}>{ing.name} grams</label>
                    <input
                      id={`g-${it.ing}`} type="number" min={0} step={0.5} value={it.grams}
                      onChange={(e) => {
                        const g = Math.max(0, Number(e.target.value) || 0);
                        commit(items.map((x) => (x.ing === it.ing ? { ...x, grams: g } : x)).filter((x) => x.grams > 0), `Set ${ing.name} to ${g} g`);
                      }}
                      className="w-16 rounded-md border bg-background px-2 py-1 text-right font-mono text-sm"
                    />
                    <span className="text-xs text-muted-foreground">g</span>
                    <button className="btn-line !p-1.5" aria-label={`Increase ${ing.name}`} onClick={() => fix({ kind: "scale", ing: it.ing, factor: 1.25 }, `Increased ${ing.name}`)}><Plus className="h-3.5 w-3.5" /></button>
                  </div>
                  <div className="col-span-2 flex items-center gap-1 sm:col-span-1">
                    {swaps.length > 0 && (
                      <label className="flex items-center gap-1 rounded-full border px-2 py-1 text-xs">
                        <Replace className="h-3 w-3 text-saffron" />
                        <span className="sr-only">Replace {ing.name}</span>
                        <select
                          value=""
                          onChange={(e) => {
                            const s = swaps.find((x) => x.to === e.target.value);
                            if (s) fix({ kind: "replace", from: it.ing, to: s.to, ratio: s.ratio }, `Swapped ${ing.name} for ${ING[s.to].name}`);
                          }}
                          className="bg-transparent text-xs outline-none"
                        >
                          <option value="">Replace…</option>
                          {swaps.map((s) => <option key={s.to} value={s.to}>{ING[s.to].name}</option>)}
                        </select>
                      </label>
                    )}
                    <button className="btn-line !p-1.5" aria-label={`Remove ${ing.name}`} onClick={() => commit(items.filter((x) => x.ing !== it.ing), `Removed ${ing.name}`)}><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </li>
              );
            })}
          </ul>

          <form
            className="flex flex-wrap items-center gap-2 border-t p-4"
            onSubmit={(e) => { e.preventDefault(); if (addId) { fix({ kind: "add", ing: addId, grams: 10 }, `Added 10 g ${ING[addId].name}`); setAddId(""); } }}
          >
            <label htmlFor="add" className="eyebrow">Add ingredient</label>
            <select id="add" value={addId} onChange={(e) => setAddId(e.target.value)} className="min-w-0 flex-1 rounded-full border bg-background px-3 py-2 text-sm">
              <option value="">Choose…</option>
              {addables.map((i) => <option key={i.id} value={i.id}>{i.name} · {i.group}</option>)}
            </select>
            <button className="btn-lime" disabled={!addId}><Plus className="h-4 w-4" /> Add 10 g</button>
          </form>

          {suggestions.length > 0 && (
            <div className="border-t p-4">
              <p className="eyebrow mb-2">Suggested changes</p>
              <ul className="space-y-2">
                {suggestions.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center gap-3 rounded-lg border p-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm">{s.fixLabel}</p>
                      <p className="text-xs text-muted-foreground">{s.why}</p>
                    </div>
                    <button className="btn-line !py-1.5 !text-xs" onClick={() => fix(s.fix!, s.fixLabel!)}>Try it</button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>

        <section className="space-y-5" aria-label="Results">
          <div className={cn("panel relative overflow-hidden p-5", win && "border-primary")}>
            {win && <Sparks key={`${match}-${health}`} />}
            <div className="flex items-center justify-around">
              <ScoreRing value={match} label="Taste match" />
              <ScoreRing value={health} label="Nutrition" tone="saffron" />
              <div className="text-center">
                <p className={cn("font-mono text-2xl", health - baseHealth > 0 ? "text-primary" : health - baseHealth < 0 ? "text-destructive" : "text-muted-foreground")}>
                  {health - baseHealth >= 0 ? "+" : ""}{health - baseHealth}
                </p>
                <p className="eyebrow">vs original</p>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-3 rounded-lg bg-muted/50 p-3" role="status" aria-live="polite">
              <ChefZest size={52} mood={win ? "happy" : "idle"} key={win ? "w" : reaction} />
              <p className="text-sm">{win ? "Chef Zest found something worth tasting — big nutrition gain, taste mostly intact." : reaction}</p>
            </div>
          </div>

          <div className="panel p-4">
            <p className="eyebrow mb-1">Flavor profile · original vs experiment</p>
            <FlavorRadar a={bf} b={cf} aLabel="Original" bLabel="Experiment" height={260} />
          </div>

          <NutritionDiff a={bn} b={cn_} aLabel="Original" bLabel="Now" />

          <form
            className="panel flex flex-wrap items-center gap-2 p-4"
            onSubmit={(e) => {
              e.preventDefault();
              const n = name.trim() || `${base.name} v${mine.length + 1}`;
              actions.saveExperiment({ name: n, baseId: dish, items, match, health });
              setName("");
              toast.success(`Saved “${n}” to My Cravings`);
            }}
          >
            <label htmlFor="ename" className="sr-only">Experiment name</label>
            <input id="ename" value={name} onChange={(e) => setName(e.target.value)} placeholder={`${base.name} v${mine.length + 1}`} className="min-w-0 flex-1 rounded-full border bg-background px-4 py-2 text-sm" />
            <button className="btn-lime" disabled={h.i === 0}><Save className="h-4 w-4" /> Save experiment</button>
          </form>
        </section>
      </div>

      <section className="mt-10">
        <p className="eyebrow">Saved versions of {base.name}</p>
        {mine.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">No saved versions yet. Make a change and save it to compare later.</p>
        ) : (
          <>
            <div className="mt-3 overflow-x-auto rounded-lg border">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left text-muted-foreground">
                  <tr><th className="px-3 py-2">Compare</th><th className="px-3 py-2">Version</th><th className="px-3 py-2 text-right">Match</th><th className="px-3 py-2 text-right">Nutrition</th><th className="px-3 py-2 text-right">kcal</th><th className="px-3 py-2" /></tr>
                </thead>
                <tbody>
                  {mine.map((e) => (
                    <tr key={e.id} className="border-t">
                      <td className="px-3 py-2">
                        <input type="checkbox" aria-label={`Compare ${e.name}`} checked={compare.includes(e.id)} onChange={() => setCompare((c) => (c.includes(e.id) ? c.filter((x) => x !== e.id) : [...c, e.id].slice(-2)))} className="accent-primary" />
                      </td>
                      <td className="px-3 py-2">{e.name}</td>
                      <td className="px-3 py-2 text-right font-mono">{e.match}%</td>
                      <td className="px-3 py-2 text-right font-mono">{e.health}</td>
                      <td className="px-3 py-2 text-right font-mono">{nutritionOf(e.items).kcal}</td>
                      <td className="px-3 py-2 text-right">
                        <button className="btn-line !px-2 !py-1 !text-xs" onClick={() => { commit(e.items, `Loaded “${e.name}”`); }}><FolderOpen className="h-3 w-3" /> Load</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {compare.length === 2 && (() => {
              const [a, b] = compare.map((id) => mine.find((e) => e.id === id)!).filter(Boolean);
              if (!a || !b) return null;
              return (
                <div className="mt-4 grid gap-4 lg:grid-cols-2">
                  <NutritionDiff a={nutritionOf(a.items)} b={nutritionOf(b.items)} aLabel={a.name} bLabel={b.name} />
                  <div className="panel p-3"><FlavorRadar a={flavorOf(a.items)} b={flavorOf(b.items)} aLabel={a.name} bLabel={b.name} height={240} /></div>
                </div>
              );
            })()}
            {compare.length === 1 && <p className="mt-2 text-xs text-muted-foreground">Pick one more version to compare.</p>}
          </>
        )}
      </section>
    </div>
  );
}

function Sparks() {
  const dots = Array.from({ length: 10 }, (_, i) => {
    const a = (i / 10) * Math.PI * 2;
    return { dx: `${Math.cos(a) * 70}px`, dy: `${Math.sin(a) * 50}px`, c: i % 2 ? "bg-primary" : "bg-saffron" };
  });
  return (
    <div className="pointer-events-none absolute left-1/2 top-10" aria-hidden>
      {dots.map((d, i) => (
        <span key={i} className={cn("animate-spark absolute h-1.5 w-1.5 rounded-full", d.c)} style={{ ["--dx" as string]: d.dx, ["--dy" as string]: d.dy }} />
      ))}
    </div>
  );
}
