import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Dna, FlaskConical } from "lucide-react";
import { DishImage, SaveButton } from "@/components/dish";
import { FlavorRadar, ScoreRing } from "@/components/charts";
import { NutritionDiff, RecipeLinter } from "@/components/analysis";
import { ParetoMap } from "@/components/ParetoMap";
import { SectionHead } from "@/components/section";
import { ChefTip } from "@/components/brand";
import { ING, RECIPE, twinsOf } from "@/lib/flavor/data";
import { bestTwin, compareDims, flavorOf, healthScore, matchScore, nutritionOf } from "@/lib/flavor/engine";
import { DIM_LABEL } from "@/lib/flavor/types";
import { actions } from "@/lib/store";

export const Route = createFileRoute("/dish/$id")({
  loader: ({ params }) => {
    const r = RECIPE[params.id];
    if (!r) throw notFound();
    return { id: r.id, name: r.name, blurb: r.blurb };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} — flavor twin & analysis | FlavorLint` },
          { name: "description", content: `${loaderData.blurb} See its healthier flavor twin, nutrition trade-offs and recipe diagnostics.` },
          { property: "og:title", content: `${loaderData.name} — FlavorLint` },
          { property: "og:description", content: loaderData.blurb },
          { property: "og:type", content: "article" },
          { name: "twitter:card", content: "summary_large_image" },
        ]
      : [{ title: "Dish not found — FlavorLint" }, { name: "robots", content: "noindex" }],
  }),
  component: DishPage,
});

function DishPage() {
  const { id } = Route.useLoaderData();
  const dish = RECIPE[id];
  const cravingId = dish.kind === "twin" ? dish.twinOf! : dish.id;
  const original = RECIPE[cravingId];
  const twins = twinsOf(cravingId);
  const [twinId, setTwinId] = useState(dish.kind === "twin" ? dish.id : bestTwin(cravingId)?.id ?? twins[0]?.id);
  useEffect(() => setTwinId(dish.kind === "twin" ? dish.id : bestTwin(cravingId)?.id ?? twins[0]?.id), [id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => actions.log(id, "Viewed analysis"), [id]);
  const twin = RECIPE[twinId];

  const fo = flavorOf(original.items), ft = flavorOf(twin.items);
  const no = nutritionOf(original.items), nt = nutritionOf(twin.items);
  const match = matchScore(fo, ft);
  const cmp = compareDims(fo, ft);

  return (
    <div className="space-y-14">
      <Link to="/explore" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Library</Link>

      <section>
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Flavor twin report</p>
            <h1 className="font-display mt-2 text-4xl sm:text-5xl">Your flavor twin <span className="italic text-primary">is ready.</span></h1>
          </div>
          {twins.length > 1 && (
            <div className="flex flex-wrap gap-2" role="group" aria-label="Choose a twin">
              {twins.map((t) => <button key={t.id} className="chip" data-active={t.id === twinId} onClick={() => setTwinId(t.id)}>{t.name}</button>)}
            </div>
          )}
        </div>

        <div className="grid gap-4 lg:grid-cols-[1fr_auto_1fr]">
          <TwinCard id={original.id} label="Your craving" tone="saffron" />
          <div className="panel flex flex-row items-center justify-center gap-6 p-5 lg:flex-col">
            <ScoreRing value={match} label="Flavor match" />
            <ScoreRing value={healthScore(nt)} label="Twin nutrition" tone="saffron" size={70} />
            <span className="text-xs text-muted-foreground">from {healthScore(no)}</span>
          </div>
          <TwinCard id={twin.id} label="Healthier twin" tone="lime" />
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="panel p-5">
          <SectionHead eyebrow="Flavor-note comparison" title="Where they overlap" />
          <FlavorRadar a={fo} b={ft} aLabel={original.name} bLabel={twin.name} />
          <div className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
            <DimList title="Shared" items={cmp.shared} cls="tag-lime" />
            <DimList title="Only original" items={cmp.aOnly} cls="tag-saffron" />
            <DimList title="Only twin" items={cmp.bOnly} cls="tag-muted" />
          </div>
          <p className="mt-4 text-xs text-muted-foreground">Flavor notes are curated estimates combined by weight — not measured molecular similarity.</p>
        </div>
        <div className="space-y-5">
          <div className="panel p-5">
            <p className="eyebrow">Why this twin</p>
            <p className="font-display mt-2 text-xl leading-snug">{twin.why}</p>
          </div>
          <NutritionDiff a={no} b={nt} aLabel={original.name.split(" ")[0]} bLabel={twin.name.split(" ")[0]} />
          <div className="flex flex-wrap gap-2">
            <Link to="/lab" search={{ dish: original.id }} className="btn-lime"><FlaskConical className="h-4 w-4" /> Run the experiment</Link>
            <Link to="/dna" search={{ dish: original.id, twin: twin.id }} className="btn-line"><Dna className="h-4 w-4" /> Flavor DNA</Link>
          </div>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2">
        {[original, twin].map((r) => (
          <div key={r.id} className="panel p-5">
            <p className="eyebrow">{r.id === original.id ? "Original recipe" : "Twin recipe"} · per serving</p>
            <h3 className="font-display mt-1 text-2xl">{r.name}</h3>
            <ul className="mt-3 divide-y text-sm">
              {r.items.map((i) => (
                <li key={i.ing} className="flex justify-between py-1.5"><span>{ING[i.ing].name}</span><span className="font-mono text-muted-foreground">{i.grams} g</span></li>
              ))}
            </ul>
            <ol className="mt-4 list-decimal space-y-1 pl-5 text-sm text-muted-foreground">{r.steps.map((s) => <li key={s}>{s}</li>)}</ol>
          </div>
        ))}
      </section>

      <section>
        <SectionHead eyebrow="Taste–Health Pareto map" title="Every option, every trade-off" />
        <ParetoMap cravingId={cravingId} />
      </section>

      <section>
        <SectionHead eyebrow="Recipe linter" title={<>Debug report for <span className="italic">{original.name}</span></>} />
        <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
          <RecipeLinter key={original.id} recipeId={original.id} name={original.name} baseItems={original.items} />
          <ChefTip>Red lines are things the rules flagged. Saffron ones are optional ideas — taste before you commit.</ChefTip>
        </div>
      </section>
    </div>
  );
}

function TwinCard({ id, label, tone }: { id: string; label: string; tone: "lime" | "saffron" }) {
  const r = RECIPE[id];
  const n = nutritionOf(r.items);
  return (
    <article className="panel group overflow-hidden">
      <div className="relative aspect-[16/10] overflow-hidden">
        <DishImage id={r.id} name={r.name} eager className="h-full w-full transition-transform duration-700 group-hover:scale-105" />
        <div className="photo-shade absolute inset-0" />
        <span className={`${tone === "lime" ? "tag-lime" : "tag-saffron"} glass absolute left-3 top-3`}>{label}</span>
        <SaveButton id={r.id} name={r.name} className="absolute right-3 top-3" />
        <div className="absolute bottom-3 left-4 right-4">
          <h2 className="font-display text-3xl">{r.name}</h2>
          <p className="text-sm text-muted-foreground">{r.blurb}</p>
        </div>
      </div>
      <dl className="grid grid-cols-4 divide-x text-center">
        {[["kcal", n.kcal], ["protein", `${n.protein}g`], ["sat fat", `${n.satFat}g`], ["fibre", `${n.fiber}g`]].map(([k, v]) => (
          <div key={k} className="px-2 py-3">
            <dt className="eyebrow !text-[0.6rem]">{k}</dt>
            <dd className="mt-0.5 font-mono text-sm">{v}</dd>
          </div>
        ))}
      </dl>
    </article>
  );
}

function DimList({ title, items, cls }: { title: string; items: string[]; cls: string }) {
  return (
    <div>
      <p className="eyebrow mb-1.5">{title}</p>
      <div className="flex flex-wrap gap-1">
        {items.length ? items.map((d) => <span key={d} className={cls}>{DIM_LABEL[d as keyof typeof DIM_LABEL].split(" ")[0]}</span>) : <span className="text-xs text-muted-foreground">—</span>}
      </div>
    </div>
  );
}
