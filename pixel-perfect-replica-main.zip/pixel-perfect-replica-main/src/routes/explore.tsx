import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import { DishCard } from "@/components/dish";
import { ChefTip } from "@/components/brand";
import { PageHead } from "@/components/section";
import { Skeleton } from "@/components/ui/skeleton";
import { RECIPES } from "@/lib/flavor/data";
import { flavorOf, healthScore, nutritionOf } from "@/lib/flavor/engine";
import type { Category } from "@/lib/flavor/types";

const CATS: Category[] = ["Indian", "Italian", "Asian", "Snacks", "Vegetarian", "Drinks"];
const SORTS = { relevance: "Relevance", kcal: "Lowest calories", protein: "Most protein", health: "Best nutrition score", spicy: "Spiciest" } as const;
type Sort = keyof typeof SORTS;

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>): { q?: string; cat?: string } => ({
    q: typeof s.q === "string" ? s.q : undefined,
    cat: typeof s.cat === "string" ? s.cat : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Explore cravings — FlavorLint" },
      { name: "description", content: "Search and filter dishes and their healthier flavor twins by cuisine, calories and protein." },
      { property: "og:title", content: "Explore cravings — FlavorLint" },
      { property: "og:description", content: "A searchable library of cravings and flavor twins." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Explore,
});

function Explore() {
  const { q = "", cat } = Route.useSearch();
  const nav = useNavigate({ from: "/explore" });
  const [text, setText] = useState(q);
  const [sort, setSort] = useState<Sort>("relevance");
  const [kind, setKind] = useState<"all" | "craving" | "twin">("all");
  const [pending, setPending] = useState(false);

  useEffect(() => setText(q), [q]);
  useEffect(() => {
    if (text === q) return;
    setPending(true);
    const t = setTimeout(() => {
      nav({ search: (p) => ({ ...p, q: text || undefined }), replace: true });
      setPending(false);
    }, 250);
    return () => clearTimeout(t);
  }, [text, q, nav]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    let list = RECIPES.filter(
      (r) =>
        (!s || r.name.toLowerCase().includes(s) || r.blurb.toLowerCase().includes(s) || r.categories.some((c) => c.toLowerCase() === s)) &&
        (!cat || r.categories.includes(cat as Category)) &&
        (kind === "all" || r.kind === kind),
    );
    const by: Record<Sort, (r: (typeof RECIPES)[number]) => number> = {
      relevance: () => 0,
      kcal: (r) => nutritionOf(r.items).kcal,
      protein: (r) => -nutritionOf(r.items).protein,
      health: (r) => -healthScore(nutritionOf(r.items)),
      spicy: (r) => -flavorOf(r.items).spicy,
    };
    if (sort !== "relevance") list = [...list].sort((a, b) => by[sort](a) - by[sort](b));
    return list;
  }, [q, cat, sort, kind]);

  return (
    <div>
      <PageHead eyebrow="Craving library" title={<>Explore <span className="italic text-primary">every</span> craving</>} sub="Originals and their flavor twins, side by side. Tap a dish to see what it's really made of." />

      <div className="panel mb-6 space-y-4 p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex min-w-[240px] flex-1 items-center gap-2 rounded-full border bg-background px-4">
            <Search className="h-4 w-4 text-muted-foreground" />
            <label htmlFor="q" className="sr-only">Search dishes</label>
            <input id="q" value={text} onChange={(e) => setText(e.target.value)} placeholder="Search dishes, cuisines, notes…" className="min-w-0 flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-muted-foreground" />
            {text && <button aria-label="Clear search" onClick={() => setText("")}><X className="h-4 w-4 text-muted-foreground" /></button>}
          </div>
          <label className="flex items-center gap-2 text-sm">
            <span className="eyebrow">Sort</span>
            <select value={sort} onChange={(e) => setSort(e.target.value as Sort)} className="rounded-full border bg-background px-3 py-2 text-sm">
              {Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </label>
          <div className="flex rounded-full border p-0.5 text-xs" role="group" aria-label="Dish type">
            {(["all", "craving", "twin"] as const).map((k) => (
              <button key={k} data-active={kind === k} onClick={() => setKind(k)} className="chip !border-0">
                {k === "all" ? "All" : k === "craving" ? "Originals" : "Twins"}
              </button>
            ))}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="chip" data-active={!cat} onClick={() => nav({ search: (p) => ({ ...p, cat: undefined }) })}>All cuisines</button>
          {CATS.map((c) => (
            <button key={c} className="chip" data-active={cat === c} onClick={() => nav({ search: (p) => ({ ...p, cat: cat === c ? undefined : c }) })}>{c}</button>
          ))}
        </div>
      </div>

      <p className="mb-4 text-sm text-muted-foreground" aria-live="polite">
        {pending ? "Searching…" : `${results.length} dish${results.length === 1 ? "" : "es"}`}
      </p>

      {pending ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="aspect-[4/4] rounded-xl bg-muted" />)}
        </div>
      ) : results.length ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((r) => <DishCard key={r.id} recipe={r} />)}
        </div>
      ) : (
        <div className="mx-auto max-w-md py-10">
          <ChefTip>Nothing on the menu for “{q}” yet. The demo library covers Indian, Italian and snack favorites — try “paneer” or “pasta”.</ChefTip>
        </div>
      )}
    </div>
  );
}
