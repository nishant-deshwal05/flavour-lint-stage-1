import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Database, FlaskRound, Info } from "lucide-react";
import { PageHead } from "@/components/section";
import { DishPicker } from "@/components/DishPicker";
import { FlavorRadar } from "@/components/charts";
import { DATA_SOURCE, ING, RECIPE, twinsOf } from "@/lib/flavor/data";
import { bestTwin, compareDims, contributions, flavorOf, matchScore } from "@/lib/flavor/engine";
import { DIMS, DIM_LABEL, type Dim } from "@/lib/flavor/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dna")({
  validateSearch: (s: Record<string, unknown>): { dish?: string; twin?: string } => ({
    dish: typeof s.dish === "string" && RECIPE[s.dish]?.kind === "craving" ? s.dish : undefined,
    twin: typeof s.twin === "string" && RECIPE[s.twin] ? s.twin : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Flavor DNA Explorer — FlavorLint" },
      { name: "description", content: "See which ingredients build each flavor note, and how a dish compares with its healthier twin." },
      { property: "og:title", content: "Flavor DNA Explorer — FlavorLint" },
      { property: "og:description", content: "Ingredient-to-flavor maps and twin comparisons." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DnaPage,
});

function DnaPage() {
  const { dish = "butter-chicken", twin } = Route.useSearch();
  const nav = useNavigate({ from: "/dna" });
  const base = RECIPE[dish];
  const twins = twinsOf(dish);
  const t = RECIPE[twin && RECIPE[twin].twinOf === dish ? twin : bestTwin(dish)?.id ?? twins[0].id];
  const [view, setView] = useState<"original" | "twin">("original");
  const [focus, setFocus] = useState<{ type: "ing" | "dim"; id: string } | null>(null);

  const fa = flavorOf(base.items), fb = flavorOf(t.items);
  const cmp = compareDims(fa, fb);
  const recipe = view === "original" ? base : t;
  const contrib = useMemo(() => contributions(recipe.items), [recipe]);
  const flavor = view === "original" ? fa : fb;

  // Network layout
  const ings = recipe.items.filter((i) => contrib.some((c) => (c.parts.find((p) => p.ing === i.ing)?.share ?? 0) > 0.08));
  const H = Math.max(ings.length, DIMS.length) * 42 + 20;
  const yI = (i: number) => 20 + i * ((H - 40) / Math.max(1, ings.length - 1));
  const yD = (i: number) => 20 + i * ((H - 40) / (DIMS.length - 1));

  const focusText = (() => {
    if (!focus) return null;
    if (focus.type === "dim") {
      const c = contrib.find((x) => x.dim === focus.id)!;
      const top = [...c.parts].sort((a, b) => b.share - a.share).filter((p) => p.share > 0).slice(0, 4);
      return { title: `${DIM_LABEL[focus.id as Dim]} · ${flavor[focus.id as Dim]}/10`, lines: top.map((p) => `${ING[p.ing].name} — ${Math.round(p.share * 100)}% of this note`) };
    }
    const it = recipe.items.find((i) => i.ing === focus.id)!;
    return {
      title: `${ING[focus.id].name} · ${it.grams} g`,
      lines: contrib.map((c) => ({ d: c.dim, s: c.parts.find((p) => p.ing === focus.id)?.share ?? 0 })).filter((x) => x.s > 0.01).sort((a, b) => b.s - a.s).map((x) => `${Math.round(x.s * 100)}% of ${DIM_LABEL[x.d].toLowerCase()}`),
    };
  })();

  return (
    <div>
      <PageHead
        eyebrow="Flavor DNA Explorer"
        title={<>What makes <span className="italic text-primary">{base.name}</span> taste like itself</>}
        sub="Mode: flavor-note comparison. Compound-level data isn't connected, so no molecules are shown — only curated ingredient flavor notes."
        action={<DishPicker value={dish} label="Dish" onChange={(d) => nav({ search: { dish: d } })} />}
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="panel p-5">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <p className="eyebrow">Profile · {matchScore(fa, fb)}% match</p>
            <div className="flex flex-wrap gap-1.5">
              {twins.map((x) => <button key={x.id} className="chip !py-1 !text-xs" data-active={x.id === t.id} onClick={() => nav({ search: { dish, twin: x.id } })}>{x.name}</button>)}
            </div>
          </div>
          <FlavorRadar a={fa} b={fb} aLabel={base.name} bLabel={t.name} />
        </div>
        <div className="panel p-5">
          <p className="eyebrow mb-3">Dimension breakdown</p>
          <ul className="space-y-2.5">
            {DIMS.map((d) => {
              const status = cmp.shared.includes(d) ? "shared" : cmp.aOnly.includes(d) ? "original only" : cmp.bOnly.includes(d) ? "twin only" : "faint in both";
              return (
                <li key={d}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <span>{DIM_LABEL[d]}</span>
                    <span className={cn(status === "shared" ? "tag-lime" : status === "original only" ? "tag-saffron" : "tag-muted")}>{status}</span>
                  </div>
                  <div className="relative h-2 rounded-full bg-muted">
                    <div className="absolute inset-y-0 left-0 rounded-full bg-saffron/70 transition-all duration-500" style={{ width: `${fa[d] * 10}%` }} />
                    <div className="absolute -bottom-1.5 h-1 rounded-full bg-primary transition-all duration-500" style={{ width: `${fb[d] * 10}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
          <p className="mt-4 text-xs text-muted-foreground"><span className="text-saffron">Saffron</span> = {base.name}, <span className="text-primary">lime</span> = {t.name}. A note counts as present at 3/10 or higher.</p>
        </div>
      </div>

      <section className="mt-8 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="panel p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <p className="eyebrow">Ingredient → flavor-note map</p>
            <div className="flex rounded-full border p-0.5">
              <button className="chip !border-0 !py-1 !text-xs" data-active={view === "original"} onClick={() => { setView("original"); setFocus(null); }}>Original</button>
              <button className="chip !border-0 !py-1 !text-xs" data-active={view === "twin"} onClick={() => { setView("twin"); setFocus(null); }}>Twin</button>
            </div>
          </div>
          <svg viewBox={`0 0 600 ${H}`} className="w-full" role="group" aria-label="Ingredient to flavor note network">
            {ings.map((it, i) =>
              DIMS.map((d, j) => {
                const s = contrib.find((c) => c.dim === d)!.parts.find((p) => p.ing === it.ing)?.share ?? 0;
                if (s < 0.08) return null;
                const on = !focus || (focus.type === "ing" ? focus.id === it.ing : focus.id === d);
                return <path key={`${it.ing}-${d}`} d={`M170 ${yI(i)} C 300 ${yI(i)}, 300 ${yD(j)}, 430 ${yD(j)}`} fill="none" stroke={on ? "var(--primary)" : "var(--border)"} strokeOpacity={on ? 0.25 + s * 0.75 : 0.5} strokeWidth={1 + s * 6} style={{ transition: "all .3s" }} />;
              }),
            )}
            {ings.map((it, i) => (
              <g key={it.ing} role="button" tabIndex={0} aria-label={`${ING[it.ing].name} details`} className="cursor-pointer" onClick={() => setFocus({ type: "ing", id: it.ing })} onKeyDown={(e) => e.key === "Enter" && setFocus({ type: "ing", id: it.ing })}>
                <circle cx={170} cy={yI(i)} r={7} fill={focus?.id === it.ing ? "var(--primary)" : "var(--surface-2)"} stroke="var(--sage)" />
                <text x={156} y={yI(i) + 4} textAnchor="end" fill="var(--foreground)" fontSize="13">{ING[it.ing].name}</text>
              </g>
            ))}
            {DIMS.map((d, j) => (
              <g key={d} role="button" tabIndex={0} aria-label={`${DIM_LABEL[d]} details`} className="cursor-pointer" onClick={() => setFocus({ type: "dim", id: d })} onKeyDown={(e) => e.key === "Enter" && setFocus({ type: "dim", id: d })}>
                <circle cx={430} cy={yD(j)} r={5 + flavor[d] * 1.2} fill="var(--saffron)" fillOpacity={focus?.id === d ? 0.9 : 0.35} stroke="var(--saffron)" />
                <text x={452} y={yD(j) + 4} fill="var(--foreground)" fontSize="13">{DIM_LABEL[d].split(" ")[0]} <tspan fill="var(--muted-foreground)">{flavor[d]}</tspan></text>
              </g>
            ))}
          </svg>
          <p className="mt-2 text-xs text-muted-foreground">Line thickness = share of that note contributed by the ingredient (calculated from grams × curated intensity). Click any node.</p>
        </div>

        <div className="space-y-5">
          <div className="panel p-5" aria-live="polite">
            <p className="eyebrow mb-2">Node details</p>
            {focusText ? (
              <>
                <p className="font-display text-xl">{focusText.title}</p>
                <ul className="mt-2 space-y-1 text-sm text-muted-foreground">{focusText.lines.map((l) => <li key={l}>{l}</li>)}</ul>
                <span className="tag-saffron mt-3">calculated estimate</span>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">Select an ingredient or flavor note to see how they connect.</p>
            )}
          </div>
          <div className="panel p-5">
            <p className="eyebrow mb-3">Sources & evidence</p>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-2"><Database className="mt-0.5 h-4 w-4 shrink-0 text-saffron" /><span><b className="font-semibold">Curated</b> — ingredient flavor notes (0–10) and nutrition per 100 g. {DATA_SOURCE.label}.</span></li>
              <li className="flex gap-2"><FlaskRound className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><span><b className="font-semibold">Calculated</b> — dish profiles, match %, shares, nutrition per serving.</span></li>
              <li className="flex gap-2"><Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" /><span><b className="font-semibold">Unavailable</b> — measured flavor compounds. FlavorDB isn't connected, so no molecular similarity is claimed.</span></li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
