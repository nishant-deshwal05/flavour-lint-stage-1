import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Search, Sparkles } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Botanical, ChefZest } from "@/components/brand";
import { DishCard, DishImage } from "@/components/dish";
import { FlavorRadar } from "@/components/charts";
import { CRAVINGS, RECIPE, RECIPES } from "@/lib/flavor/data";
import { bestTwin, flavorOf } from "@/lib/flavor/engine";
import { useAppState } from "@/lib/store";
import { SectionHead } from "@/components/section";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FlavorLint — Same Craving. Smarter Choices." },
      { name: "description", content: "Search a dish you crave and discover a healthier flavor twin, with flavor and nutrition trade-offs explained." },
      { property: "og:title", content: "FlavorLint — Same Craving. Smarter Choices." },
      { property: "og:description", content: "Decode your cravings and find healthier flavor twins." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const POPULAR = ["butter-chicken", "biryani", "maggi", "pizza", "paneer-tikka"];

function findDish(q: string) {
  const s = q.trim().toLowerCase();
  if (!s) return undefined;
  return RECIPES.find((r) => r.name.toLowerCase() === s) ?? RECIPES.find((r) => r.name.toLowerCase().includes(s) || r.id.includes(s.replace(/\s+/g, "-")));
}

function Home() {
  const [q, setQ] = useState("");
  const nav = useNavigate();
  const { history, saved } = useAppState();
  const preview = RECIPE["butter-chicken"];
  const twin = RECIPE[bestTwin("butter-chicken")?.id ?? "tandoori-paneer-bowl"];
  const recent = [...new Set(history.map((h) => h.recipeId))].slice(0, 4).map((id) => RECIPE[id]).filter(Boolean);
  const picks = saved.length
    ? saved.map((id) => RECIPE[id]).filter((r) => r?.kind === "craving").map((r) => RECIPE[bestTwin(r.id)?.id ?? ""]).filter(Boolean).slice(0, 3)
    : RECIPES.filter((r) => r.kind === "twin" && ["tandoori-paneer-bowl", "lentil-pasta", "millet-biryani"].includes(r.id));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const hit = findDish(q);
    if (hit) nav({ to: "/dish/$id", params: { id: hit.id } });
    else nav({ to: "/explore", search: { q } });
  };

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-2xl border shadow-soft">
        <img src={hero} alt="Tandoori paneer grain bowl with herbs and spices" width={1600} height={1104} className="absolute inset-0 h-full w-full object-cover object-right" />
        <div className="hero-shade absolute inset-0" />
        <Botanical className="absolute -left-6 bottom-0 h-64 w-40 opacity-30 animate-sway" />
        <div className="relative max-w-xl px-6 py-14 sm:px-10 sm:py-20">
          <p className="eyebrow">Flavor intelligence studio</p>
          <h1 className="font-display mt-4 text-5xl leading-[0.95] sm:text-7xl">
            Same craving.<br />
            <span className="italic text-primary">Smarter</span> choices.
          </h1>
          <p className="mt-5 max-w-md text-muted-foreground">
            Unlock the science behind your favorite flavors. Find healthier twins, experiment with ingredients, and debug recipes — without blindly sacrificing taste.
          </p>
          <form onSubmit={submit} className="glass mt-8 flex items-center gap-2 rounded-full p-1.5 pl-5" role="search">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <label htmlFor="craving" className="sr-only">What are you craving?</label>
            <input
              id="craving"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="What are you craving? Try “biryani”"
              className="min-w-0 flex-1 bg-transparent py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
            <button type="submit" className="btn-lime">Decode <ArrowRight className="h-4 w-4" /></button>
          </form>
          <div className="mt-4 flex flex-wrap gap-2">
            {POPULAR.map((id) => (
              <Link key={id} to="/dish/$id" params={{ id }} className="chip glass">{RECIPE[id].name}</Link>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        <div className="panel relative flex items-end gap-4 overflow-hidden p-6">
          <ChefZest size={140} className="-mb-6 shrink-0" />
          <div className="pb-2">
            <p className="eyebrow">Today's hint</p>
            <p className="font-display mt-2 text-2xl leading-tight">“Cravings are mostly about five or six flavor notes. Keep those, and you can change a lot underneath.”</p>
            <p className="mt-3 text-sm text-muted-foreground">— Chef Zest, part-time tasting scientist</p>
          </div>
        </div>
        <div className="panel grid gap-4 p-6 sm:grid-cols-[1fr_1.1fr]">
          <div>
            <p className="eyebrow">Flavor DNA preview</p>
            <h2 className="font-display mt-2 text-2xl">{preview.name} <span className="text-muted-foreground">vs</span> <span className="italic text-primary">{twin.name}</span></h2>
            <p className="mt-2 text-sm text-muted-foreground">Overlapping shapes mean overlapping flavor notes. Where they part ways is where you'll taste the difference.</p>
            <div className="mt-4 flex gap-2">
              <Link to="/dish/$id" params={{ id: preview.id }} className="btn-lime">See the twin</Link>
              <Link to="/dna" search={{ dish: preview.id }} className="btn-line">Open Flavor DNA</Link>
            </div>
          </div>
          <FlavorRadar a={flavorOf(preview.items)} b={flavorOf(twin.items)} aLabel={preview.name} bLabel={twin.name} height={260} />
        </div>
      </section>

      {recent.length > 0 && (
        <section>
          <SectionHead eyebrow="Picking up where you left off" title="Recently explored" />
          <div className="flex gap-4 overflow-x-auto pb-2">
            {recent.map((r) => (
              <Link key={r.id} to="/dish/$id" params={{ id: r.id }} className="group panel flex w-64 shrink-0 items-center gap-3 overflow-hidden p-2 pr-4">
                <DishImage id={r.id} name={r.name} className="h-16 w-16 shrink-0 rounded-lg" />
                <span className="font-display text-lg leading-tight">{r.name}</span>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section>
        <SectionHead
          eyebrow={saved.length ? "Based on your saved cravings" : "Demo picks — save cravings to personalise"}
          title="Twins worth tasting"
          action={<Link to="/explore" className="btn-line">Browse all <ArrowRight className="h-4 w-4" /></Link>}
        />
        {picks.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {picks.map((r) => <DishCard key={r.id} recipe={r} />)}
          </div>
        ) : (
          <p className="text-muted-foreground">Save a craving to see personalised twins here.</p>
        )}
      </section>

      <section>
        <SectionHead eyebrow="The craving library" title="Start from what you love" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          {CRAVINGS.map((r) => (
            <Link key={r.id} to="/dish/$id" params={{ id: r.id }} className="group relative aspect-[3/4] overflow-hidden rounded-xl border">
              <DishImage id={r.id} name={r.name} className="h-full w-full transition-transform duration-700 group-hover:scale-110" />
              <div className="photo-shade absolute inset-0" />
              <span className="font-display absolute bottom-3 left-3 right-3 text-lg leading-tight">{r.name}</span>
            </Link>
          ))}
        </div>
        <p className="mt-6 flex items-center gap-2 text-xs text-muted-foreground"><Sparkles className="h-3.5 w-3.5 text-saffron" /> All scores come from a curated demo dataset and transparent formulas — no external database or AI model is involved.</p>
      </section>
    </div>
  );
}
