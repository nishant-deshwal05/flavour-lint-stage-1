import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/section";
import { ChefZest } from "@/components/brand";
import { INGREDIENTS, RECIPE } from "@/lib/flavor/data";
import { ALL_PRIORITIES, PRIORITY_LABEL } from "@/lib/flavor/engine";
import { DIMS, DIM_LABEL } from "@/lib/flavor/types";
import { actions, useAppState } from "@/lib/store";

const DIETS = ["Vegetarian", "High protein", "Low sodium", "Lower fat", "No added sugar"];

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile & taste preferences — FlavorLint" },
      { name: "description", content: "Set your favorite flavor notes, dietary filters, nutrition priorities and review your history." },
      { property: "og:title", content: "Profile — FlavorLint" },
      { property: "og:description", content: "Your flavor preferences and food history." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Profile,
});

function toggle<T>(list: T[], v: T) {
  return list.includes(v) ? list.filter((x) => x !== v) : [...list, v];
}

function Profile() {
  const { prefs, history, saved, experiments } = useAppState();
  return (
    <div>
      <PageHead eyebrow="Craving passport" title={<>Your <span className="italic text-primary">palate</span>, on file</>} sub="Preferences are stored on this device only." />

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <Block title="Flavor notes you love">
            {DIMS.map((d) => <button key={d} className="chip" data-active={prefs.flavors.includes(d)} aria-pressed={prefs.flavors.includes(d)} onClick={() => actions.setPrefs({ flavors: toggle(prefs.flavors, d) })}>{DIM_LABEL[d]}</button>)}
          </Block>
          <Block title="Dietary filters">
            {DIETS.map((d) => <button key={d} className="chip" data-active={prefs.diet.includes(d)} aria-pressed={prefs.diet.includes(d)} onClick={() => actions.setPrefs({ diet: toggle(prefs.diet, d) })}>{d}</button>)}
          </Block>
          <Block title="Nutrition priorities (used by the Pareto map)">
            {ALL_PRIORITIES.map((p) => <button key={p} className="chip" data-active={prefs.priorities.includes(p)} aria-pressed={prefs.priorities.includes(p)} onClick={() => { const n = toggle(prefs.priorities, p); if (n.length) actions.setPrefs({ priorities: n }); }}>{PRIORITY_LABEL[p]}</button>)}
          </Block>
          <Block title="Preferred ingredients">
            {INGREDIENTS.filter((i) => ["Protein", "Grains", "Herbs", "Spices"].includes(i.group)).map((i) => (
              <button key={i.id} className="chip !text-xs" data-active={prefs.favIngredients.includes(i.id)} aria-pressed={prefs.favIngredients.includes(i.id)} onClick={() => actions.setPrefs({ favIngredients: toggle(prefs.favIngredients, i.id) })}>{i.name}</button>
            ))}
          </Block>
        </div>

        <aside className="space-y-6">
          <div className="panel flex items-center gap-4 p-5">
            <ChefZest size={72} />
            <dl className="grid flex-1 grid-cols-3 text-center">
              {[["saved", saved.length], ["experiments", experiments.length], ["visits", history.length]].map(([k, v]) => (
                <div key={k}><dd className="font-display text-3xl text-primary">{v}</dd><dt className="eyebrow !text-[0.55rem]">{k}</dt></div>
              ))}
            </dl>
          </div>
          <div className="panel p-5">
            <div className="mb-3 flex items-center justify-between">
              <p className="eyebrow">History</p>
              {history.length > 0 && <button className="text-xs text-muted-foreground hover:text-foreground" onClick={actions.clearHistory}>Clear</button>}
            </div>
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground">Dishes you open will appear here.</p>
            ) : (
              <ol className="relative space-y-3 border-l pl-4">
                {history.slice(0, 12).map((h) => (
                  <li key={h.id} className="text-sm">
                    <span className="absolute -left-1 mt-1.5 h-2 w-2 rounded-full bg-sage" />
                    <Link to="/dish/$id" params={{ id: h.recipeId }} className="hover:text-primary">{RECIPE[h.recipeId]?.name}</Link>
                    <p className="text-xs text-muted-foreground">{h.label} · {new Date(h.at).toLocaleString()}</p>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="panel p-5">
      <p className="eyebrow mb-3">{title}</p>
      <div className="flex flex-wrap gap-2">{children}</div>
    </section>
  );
}
