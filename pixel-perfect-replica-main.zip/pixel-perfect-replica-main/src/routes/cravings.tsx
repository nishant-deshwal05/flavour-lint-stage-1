import { createFileRoute, Link } from "@tanstack/react-router";
import { FlaskConical, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { PageHead, SectionHead } from "@/components/section";
import { DishCard } from "@/components/dish";
import { ChefTip } from "@/components/brand";
import { RECIPE } from "@/lib/flavor/data";
import { nutritionOf } from "@/lib/flavor/engine";
import { actions, useAppState } from "@/lib/store";

export const Route = createFileRoute("/cravings")({
  head: () => ({
    meta: [
      { title: "My Cravings — FlavorLint" },
      { name: "description", content: "Your saved cravings, flavor twins and recipe experiments in one culinary journal." },
      { property: "og:title", content: "My Cravings — FlavorLint" },
      { property: "og:description", content: "Saved cravings, twins and experiments." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Cravings,
});

function Cravings() {
  const { saved, experiments } = useAppState();
  const recipes = saved.map((id) => RECIPE[id]).filter(Boolean);
  const originals = recipes.filter((r) => r.kind === "craving");
  const twins = recipes.filter((r) => r.kind === "twin");

  return (
    <div className="space-y-12">
      <PageHead eyebrow="Craving passport" title={<>My <span className="italic text-primary">Cravings</span></>} sub="Everything you've saved, kept on this device." />

      {recipes.length === 0 && experiments.length === 0 && (
        <div className="mx-auto max-w-lg py-6 text-center">
          <ChefTip>Your passport is still blank. Tap the heart on any dish, or save an experiment from the Mutation Lab.</ChefTip>
          <Link to="/explore" className="btn-lime mt-6">Find a craving</Link>
        </div>
      )}

      {originals.length > 0 && (
        <section>
          <SectionHead eyebrow={`${originals.length} saved`} title="Saved cravings" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{originals.map((r) => <DishCard key={r.id} recipe={r} />)}</div>
        </section>
      )}
      {twins.length > 0 && (
        <section>
          <SectionHead eyebrow={`${twins.length} saved`} title="Saved flavor twins" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{twins.map((r) => <DishCard key={r.id} recipe={r} />)}</div>
        </section>
      )}
      {experiments.length > 0 && (
        <section>
          <SectionHead eyebrow={`${experiments.length} saved`} title="Recipe experiments" />
          <ul className="grid gap-3 md:grid-cols-2">
            {experiments.map((e) => (
              <li key={e.id} className="panel flex items-center gap-4 p-4">
                <FlaskConical className="h-5 w-5 shrink-0 text-primary" />
                <div className="min-w-0 flex-1">
                  <p className="font-display truncate text-lg">{e.name}</p>
                  <p className="text-xs text-muted-foreground">From {RECIPE[e.baseId]?.name} · {e.match}% match · nutrition {e.health} · {nutritionOf(e.items).kcal} kcal</p>
                </div>
                <Link to="/lab" search={{ dish: e.baseId }} className="btn-line !py-1.5 !text-xs">Open lab</Link>
                <button className="btn-line !p-2" aria-label={`Delete ${e.name}`} onClick={() => { actions.deleteExperiment(e.id); toast(`Deleted “${e.name}”`); }}><Trash2 className="h-3.5 w-3.5" /></button>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
