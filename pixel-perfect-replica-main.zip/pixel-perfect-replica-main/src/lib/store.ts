import { useSyncExternalStore } from "react";
import type { Dim, RecipeItem } from "./flavor/types";
import type { Priority } from "./flavor/engine";

export interface Experiment {
  id: string;
  name: string;
  baseId: string;
  items: RecipeItem[];
  match: number;
  health: number;
  createdAt: number;
}
export interface HistoryEntry {
  id: string;
  at: number;
  label: string;
  recipeId: string;
}
export interface AppState {
  saved: string[];
  experiments: Experiment[];
  history: HistoryEntry[];
  prefs: { flavors: Dim[]; diet: string[]; priorities: Priority[]; favIngredients: string[] };
}

const KEY = "flavorlint:v1";
const DEFAULT: AppState = {
  saved: [],
  experiments: [],
  history: [],
  prefs: { flavors: [], diet: [], priorities: ["kcal", "satFat", "sodium", "protein", "fiber"], favIngredients: [] },
};

let state: AppState = DEFAULT;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) state = { ...DEFAULT, ...JSON.parse(raw), prefs: { ...DEFAULT.prefs, ...JSON.parse(raw).prefs } };
  } catch {
    /* ignore corrupt storage */
  }
}

export function setState(fn: (s: AppState) => AppState) {
  load();
  state = fn(state);
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage full or blocked */
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useAppState(): AppState {
  return useSyncExternalStore(
    subscribe,
    () => {
      load();
      return state;
    },
    () => DEFAULT,
  );
}

const uid = () => Math.random().toString(36).slice(2, 10);

export const actions = {
  toggleSave(id: string) {
    setState((s) => ({ ...s, saved: s.saved.includes(id) ? s.saved.filter((x) => x !== id) : [id, ...s.saved] }));
  },
  log(recipeId: string, label: string) {
    setState((s) => {
      if (s.history[0]?.recipeId === recipeId && s.history[0]?.label === label) return s;
      return { ...s, history: [{ id: uid(), at: Date.now(), label, recipeId }, ...s.history].slice(0, 40) };
    });
  },
  saveExperiment(e: Omit<Experiment, "id" | "createdAt">) {
    const exp = { ...e, id: uid(), createdAt: Date.now() };
    setState((s) => ({ ...s, experiments: [exp, ...s.experiments] }));
    return exp;
  },
  deleteExperiment(id: string) {
    setState((s) => ({ ...s, experiments: s.experiments.filter((x) => x.id !== id) }));
  },
  setPrefs(p: Partial<AppState["prefs"]>) {
    setState((s) => ({ ...s, prefs: { ...s.prefs, ...p } }));
  },
  clearHistory() {
    setState((s) => ({ ...s, history: [] }));
  },
};
