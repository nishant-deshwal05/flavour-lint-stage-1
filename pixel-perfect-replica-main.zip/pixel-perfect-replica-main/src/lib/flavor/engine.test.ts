import { describe, expect, it } from "vitest";
import { applyFix, candidatesFor, matchScore, nutritionOf, paretoFront, flavorOf, lint } from "./engine";
import { RECIPE } from "./data";

describe("flavor engine", () => {
  it("identical recipes match 100%", () => {
    const f = flavorOf(RECIPE["butter-chicken"].items);
    expect(matchScore(f, f)).toBe(100);
  });

  it("nutrition scales with grams", () => {
    expect(nutritionOf([{ ing: "butter", grams: 100 }]).kcal).toBe(717);
    expect(nutritionOf([{ ing: "butter", grams: 50 }]).kcal).toBe(359);
  });

  it("replace fix swaps ingredient with ratio", () => {
    const out = applyFix([{ ing: "cream", grams: 40 }], { kind: "replace", from: "cream", to: "greek_yogurt", ratio: 1 });
    expect(out).toEqual([{ ing: "greek_yogurt", grams: 40 }]);
  });

  it("flags high saturated fat in butter chicken", () => {
    expect(lint(RECIPE["butter-chicken"].items).some((l) => l.id === "satfat-high")).toBe(true);
  });

  it("pareto front excludes dominated candidates", () => {
    const front = paretoFront([
      { id: "a", name: "a", taste: 90, health: 50, original: false },
      { id: "b", name: "b", taste: 80, health: 40, original: false },
      { id: "c", name: "c", taste: 60, health: 80, original: false },
    ]);
    expect([...front].sort()).toEqual(["a", "c"]);
  });

  it("original is always the taste reference", () => {
    const c = candidatesFor("pizza", ["kcal"]);
    expect(c.find((x) => x.original)?.taste).toBe(100);
  });
});
