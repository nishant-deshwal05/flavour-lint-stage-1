export const DIMS = ["spicy", "sweet", "savory", "acidic", "creamy", "smoky", "earthy"] as const;
export type Dim = (typeof DIMS)[number];
export type Flavor = Record<Dim, number>;

export const DIM_LABEL: Record<Dim, string> = {
  spicy: "Spicy",
  sweet: "Sweet",
  savory: "Savory / umami",
  acidic: "Acidic",
  creamy: "Creamy",
  smoky: "Smoky",
  earthy: "Earthy / herbal",
};

/** Nutrition per 100 g (ingredients) or per serving (recipes). */
export interface Nutrition {
  kcal: number;
  protein: number;
  fat: number;
  satFat: number;
  carbs: number;
  fiber: number;
  sodium: number; // mg
}

export interface Ingredient {
  id: string;
  name: string;
  group: string;
  per100: Nutrition;
  /** Flavor-note intensity 0-10 (curated demo values, not measured compounds). */
  notes: number[];
  /** How strongly a gram of this ingredient registers in the dish. */
  potency: number;
}

export interface RecipeItem {
  ing: string;
  grams: number;
}

export type Category = "Indian" | "Italian" | "Asian" | "Snacks" | "Vegetarian" | "Drinks";

export interface Recipe {
  id: string;
  name: string;
  blurb: string;
  categories: Category[];
  kind: "craving" | "twin";
  /** For twins: which craving they replace. */
  twinOf?: string;
  why?: string;
  items: RecipeItem[];
  steps: string[];
}

export type Fix =
  | { kind: "add"; ing: string; grams: number }
  | { kind: "scale"; ing: string; factor: number }
  | { kind: "replace"; from: string; to: string; ratio: number };

export interface LintFinding {
  id: string;
  severity: "issue" | "suggestion";
  category: string;
  title: string;
  why: string;
  fix?: Fix;
  fixLabel?: string;
}
