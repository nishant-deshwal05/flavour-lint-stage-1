import { ING, RECIPE, SWAPS } from "./data";
import { DIMS, type Dim, type Fix, type Flavor, type LintFinding, type Nutrition, type RecipeItem } from "./types";

const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

export function nutritionOf(items: RecipeItem[]): Nutrition {
  const t: Nutrition = { kcal: 0, protein: 0, fat: 0, satFat: 0, carbs: 0, fiber: 0, sodium: 0 };
  for (const it of items) {
    const i = ING[it.ing];
    if (!i) continue;
    const f = it.grams / 100;
    (Object.keys(t) as (keyof Nutrition)[]).forEach((k) => (t[k] += i.per100[k] * f));
  }
  (Object.keys(t) as (keyof Nutrition)[]).forEach((k) => (t[k] = round(t[k], k === "sodium" || k === "kcal" ? 0 : 1)));
  return t;
}

/** Saturating, gram-weighted flavor-note intensity (0-10). Estimate from curated notes. */
export function flavorOf(items: RecipeItem[]): Flavor {
  const total = items.reduce((s, i) => s + i.grams, 0) || 1;
  const out = {} as Flavor;
  DIMS.forEach((d, idx) => {
    let raw = 0;
    for (const it of items) {
      const i = ING[it.ing];
      if (i) raw += it.grams * i.notes[idx] * i.potency;
    }
    out[d] = round(10 * (1 - Math.exp(-raw / total / 2)), 1);
  });
  return out;
}

/** Contribution of each ingredient to each dimension (share 0-1). */
export function contributions(items: RecipeItem[]) {
  return DIMS.map((d, idx) => {
    const parts = items.map((it) => {
      const i = ING[it.ing];
      return { ing: it.ing, v: i ? it.grams * i.notes[idx] * i.potency : 0 };
    });
    const sum = parts.reduce((s, p) => s + p.v, 0) || 1;
    return { dim: d, parts: parts.map((p) => ({ ing: p.ing, share: p.v / sum })) };
  });
}

/** Flavor-note similarity 0-100 (mean absolute difference, scaled). */
export function matchScore(a: Flavor, b: Flavor): number {
  const diff = DIMS.reduce((s, d) => s + Math.abs(a[d] - b[d]), 0);
  return Math.max(0, Math.min(100, Math.round(100 * (1 - (diff / 70) * 1.6))));
}

export type Priority = "kcal" | "satFat" | "sodium" | "protein" | "fiber";
export const PRIORITY_LABEL: Record<Priority, string> = {
  kcal: "Calories",
  satFat: "Saturated fat",
  sodium: "Sodium",
  protein: "Protein",
  fiber: "Fibre",
};
export const ALL_PRIORITIES: Priority[] = ["kcal", "satFat", "sodium", "protein", "fiber"];

const clamp = (n: number) => Math.max(0, Math.min(100, n));
export function subScores(n: Nutrition): Record<Priority, number> {
  return {
    kcal: clamp(100 - (n.kcal - 250) / 5),
    satFat: clamp(100 - n.satFat * 5),
    sodium: clamp(100 - (n.sodium - 300) / 14),
    protein: clamp(n.protein * 3),
    fiber: clamp(n.fiber * 11),
  };
}

/** Transparent nutrition score 0-100 over the chosen priorities. */
export function healthScore(n: Nutrition, priorities: Priority[] = ALL_PRIORITIES): number {
  const p = priorities.length ? priorities : ALL_PRIORITIES;
  const s = subScores(n);
  return Math.round(p.reduce((t, k) => t + s[k], 0) / p.length);
}

export function applyFix(items: RecipeItem[], fix: Fix): RecipeItem[] {
  if (fix.kind === "add") {
    const ex = items.find((i) => i.ing === fix.ing);
    if (ex) return items.map((i) => (i.ing === fix.ing ? { ...i, grams: round(i.grams + fix.grams) } : i));
    return [...items, { ing: fix.ing, grams: fix.grams }];
  }
  if (fix.kind === "scale") {
    return items
      .map((i) => (i.ing === fix.ing ? { ...i, grams: round(i.grams * fix.factor) } : i))
      .filter((i) => i.grams > 0);
  }
  const from = items.find((i) => i.ing === fix.from);
  if (!from) return items;
  const rest = items.filter((i) => i.ing !== fix.from);
  return applyFix(rest, { kind: "add", ing: fix.to, grams: round(from.grams * fix.ratio) });
}

/** Rule-based recipe linter. Every rule is a simple threshold on computed values. */
export function lint(items: RecipeItem[]): LintFinding[] {
  const f = flavorOf(items);
  const n = nutritionOf(items);
  const has = (id: string) => items.some((i) => i.ing === id);
  const out: LintFinding[] = [];

  if (f.acidic < 3 && f.savory > 4) {
    out.push({
      id: "acid-low", severity: "issue", category: "Acidity balance",
      title: `Acidity is low (${f.acidic}/10) against strong savoriness (${f.savory}/10)`,
      why: "Rich, savory dishes often read flat without a sour counterpoint. A squeeze of lemon brightens without adding fat.",
      fix: { kind: "add", ing: "lemon", grams: 6 }, fixLabel: "Add 6 g lemon juice",
    });
  }
  if (f.savory < 3.5 && !has("parmesan")) {
    out.push({
      id: "umami-weak", severity: "suggestion", category: "Umami intensity",
      title: `Umami is light (${f.savory}/10)`,
      why: "Concentrated tomato adds glutamate-rich depth with very few calories.",
      fix: { kind: "add", ing: "tomato_puree", grams: 30 }, fixLabel: "Add 30 g tomato purée",
    });
  }
  if (has("sugar") && f.sweet > 3.5) {
    out.push({
      id: "sweet-high", severity: "issue", category: "Sweetness balance",
      title: `Added sugar pushes sweetness to ${f.sweet}/10`,
      why: "Halving added sugar usually keeps balance while trimming empty calories.",
      fix: { kind: "scale", ing: "sugar", factor: 0.5 }, fixLabel: "Halve the sugar",
    });
  }
  if (f.smoky < 1.5 && (has("chili") || has("garam_masala"))) {
    out.push({
      id: "smoke-low", severity: "suggestion", category: "Smoky intensity",
      title: `Smoky depth is faint (${f.smoky}/10)`,
      why: "A pinch of smoked paprika mimics tandoor char at almost zero calories.",
      fix: { kind: "add", ing: "smoked_paprika", grams: 0.8 }, fixLabel: "Add 0.8 g smoked paprika",
    });
  }
  if (n.satFat > 10) {
    const fatty = ["cream", "butter", "ghee", "paneer", "mozzarella"].find(has);
    const swap = fatty ? SWAPS[fatty]?.[0] : undefined;
    out.push({
      id: "satfat-high", severity: "issue", category: "Creaminess",
      title: `Saturated fat is ${n.satFat} g per serving`,
      why: fatty && swap
        ? `${ING[fatty].name} is the largest contributor. ${ING[swap.to].name} keeps body with far less saturated fat.`
        : "Consider lighter dairy or fat sources.",
      fix: fatty && swap ? { kind: "replace", from: fatty, to: swap.to, ratio: swap.ratio } : undefined,
      fixLabel: fatty && swap ? `Swap ${ING[fatty].name} → ${ING[swap.to].name}` : undefined,
    });
  } else if (f.creamy < 2 && f.spicy > 5) {
    out.push({
      id: "cream-low", severity: "suggestion", category: "Creaminess",
      title: "Heat with little to soften it",
      why: "A spoon of Greek yogurt rounds out chili heat while adding protein.",
      fix: { kind: "add", ing: "greek_yogurt", grams: 30 }, fixLabel: "Add 30 g Greek yogurt",
    });
  }
  if (n.sodium > 900) {
    const salty = ["tastemaker", "salt", "parmesan"].find(has);
    out.push({
      id: "sodium-high", severity: "issue", category: "Seasoning",
      title: `Sodium is ${n.sodium} mg per serving`,
      why: "Cutting the main salt source by a third is rarely noticed when acids and spices stay intact.",
      fix: salty ? { kind: "scale", ing: salty, factor: 0.66 } : undefined,
      fixLabel: salty ? `Reduce ${ING[salty].name} by a third` : undefined,
    });
  }
  return out;
}

export function compareDims(a: Flavor, b: Flavor, threshold = 3) {
  const shared: Dim[] = [], aOnly: Dim[] = [], bOnly: Dim[] = [];
  DIMS.forEach((d) => {
    const ia = a[d] >= threshold, ib = b[d] >= threshold;
    if (ia && ib) shared.push(d);
    else if (ia) aOnly.push(d);
    else if (ib) bOnly.push(d);
  });
  return { shared, aOnly, bOnly };
}

export interface Candidate {
  id: string;
  name: string;
  taste: number;
  health: number;
  original: boolean;
}

export function candidatesFor(cravingId: string, priorities: Priority[], extra: { id: string; name: string; items: RecipeItem[] }[] = []): Candidate[] {
  const base = RECIPE[cravingId];
  const bf = flavorOf(base.items);
  const list = [
    { id: base.id, name: base.name, items: base.items },
    ...Object.values(RECIPE).filter((r) => r.twinOf === cravingId),
    ...extra,
  ];
  return list.map((r) => ({
    id: r.id,
    name: r.name,
    taste: matchScore(bf, flavorOf(r.items)),
    health: healthScore(nutritionOf(r.items), priorities),
    original: r.id === base.id,
  }));
}

/** Points not beaten on both taste and health by another point. */
export function paretoFront(c: Candidate[]): Set<string> {
  const s = new Set<string>();
  c.forEach((a) => {
    const dominated = c.some((b) => b !== a && b.taste >= a.taste && b.health >= a.health && (b.taste > a.taste || b.health > a.health));
    if (!dominated) s.add(a.id);
  });
  return s;
}

/** weight 0 = all health, 1 = all taste. */
export function recommend(c: Candidate[], weight: number): Candidate | undefined {
  return [...c].sort((x, y) => weight * y.taste + (1 - weight) * y.health - (weight * x.taste + (1 - weight) * x.health))[0];
}

export function bestTwin(cravingId: string, priorities: Priority[] = ALL_PRIORITIES) {
  const c = candidatesFor(cravingId, priorities).filter((x) => !x.original);
  return recommend(c, 0.55);
}
