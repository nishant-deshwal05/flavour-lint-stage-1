import butterChicken from "@/assets/butter-chicken.jpg";
import biryani from "@/assets/biryani.jpg";
import paneerTikka from "@/assets/paneer-tikka.jpg";
import maggi from "@/assets/maggi.jpg";
import pizza from "@/assets/pizza.jpg";
import pasta from "@/assets/pasta.jpg";
import lassi from "@/assets/lassi.jpg";
import bowl from "@/assets/hero.jpg";
import milletBiryani from "@/assets/millet-biryani.jpg";
import veggiePizza from "@/assets/veggie-pizza.jpg";
import lentilPasta from "@/assets/lentil-pasta.jpg";

/** Configurable image map. Recipes without an entry render an illustrated fallback. */
export const DISH_IMAGES: Record<string, string> = {
  "butter-chicken": butterChicken,
  biryani,
  "paneer-tikka": paneerTikka,
  maggi,
  pizza,
  pasta,
  "mango-lassi": lassi,
  "tandoori-paneer-bowl": bowl,
  "millet-biryani": milletBiryani,
  "veggie-pizza": veggiePizza,
  "lentil-pasta": lentilPasta,
};
