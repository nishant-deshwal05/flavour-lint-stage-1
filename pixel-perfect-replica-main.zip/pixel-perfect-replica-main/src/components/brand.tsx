import chef from "@/assets/chef-zest.png";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-8 w-8", className)} aria-hidden>
      <rect x="1" y="1" width="38" height="38" rx="11" fill="var(--surface-2)" stroke="var(--border)" />
      <path d="M12 28 C12 17 19 11 29 11 C29 21 23 28 12 28 Z" fill="var(--primary)" />
      <path d="M12 28 L23 17" stroke="var(--primary-foreground)" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="23" cy="17" r="2" fill="var(--primary-foreground)" />
      <circle cx="17" cy="23" r="1.4" fill="var(--primary-foreground)" />
      <circle cx="30" cy="29" r="2.4" fill="var(--saffron)" />
      <path d="M23 17 L30 29" stroke="var(--saffron)" strokeWidth="1" strokeDasharray="1.5 1.5" />
    </svg>
  );
}

export function Wordmark() {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="leading-none">
        <span className="font-display text-xl text-foreground">
          Flavor<span className="italic text-primary">Lint</span>
        </span>
        <span className="eyebrow mt-1 block !text-[0.55rem]">Flavor Intelligence Studio</span>
      </span>
    </span>
  );
}

export function ChefZest({ size = 96, className, mood = "idle" }: { size?: number; className?: string; mood?: "idle" | "happy" }) {
  return (
    <img
      src={chef}
      alt="Chef Zest, FlavorLint's tasting chef"
      width={size}
      height={size}
      loading="lazy"
      className={cn("select-none drop-shadow-[0_12px_20px_rgba(0,0,0,0.5)]", mood === "happy" ? "animate-pop" : "", className)}
      style={{ width: size, height: size }}
    />
  );
}

export function ChefTip({ children, mood = "idle" }: { children: React.ReactNode; mood?: "idle" | "happy" }) {
  return (
    <div className="panel flex items-center gap-3 p-3 pr-5" role="status">
      <ChefZest size={56} mood={mood} key={String(children)} />
      <p className="text-sm text-foreground/90">
        <span className="eyebrow mb-0.5 block">Chef Zest</span>
        {children}
      </p>
    </div>
  );
}

export function Botanical({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 200" className={cn("pointer-events-none", className)} aria-hidden fill="none" stroke="var(--sage)" strokeWidth="1">
      <path d="M60 200 C60 140 58 80 62 10" />
      {[30, 60, 90, 120, 150].map((y, i) => (
        <g key={y}>
          <path d={`M61 ${y + 20} C ${i % 2 ? 90 : 30} ${y + 10}, ${i % 2 ? 105 : 15} ${y - 10}, ${i % 2 ? 100 : 20} ${y - 18} C ${i % 2 ? 85 : 35} ${y - 10}, ${i % 2 ? 70 : 50} ${y}, 61 ${y + 20}`} />
        </g>
      ))}
    </svg>
  );
}
