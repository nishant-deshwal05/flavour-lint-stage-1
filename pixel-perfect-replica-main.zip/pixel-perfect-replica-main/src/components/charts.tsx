import {
  PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Legend, Tooltip,
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, ZAxis, Cell, LabelList,
} from "recharts";
import { DIMS, DIM_LABEL, type Flavor } from "@/lib/flavor/types";
import type { Candidate } from "@/lib/flavor/engine";

const tooltipStyle = {
  background: "var(--popover)",
  border: "1px solid var(--border)",
  borderRadius: 10,
  color: "var(--foreground)",
  fontSize: 12,
};

export function FlavorRadar({ a, b, aLabel, bLabel, height = 300 }: { a: Flavor; b?: Flavor; aLabel: string; bLabel?: string; height?: number }) {
  const data = DIMS.map((d) => ({ dim: DIM_LABEL[d].split(" ")[0], a: a[d], b: b?.[d] }));
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer>
        <RadarChart data={data} outerRadius="72%">
          <PolarGrid stroke="var(--border)" />
          <PolarAngleAxis dataKey="dim" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
          <PolarRadiusAxis domain={[0, 10]} tick={false} axisLine={false} />
          <Radar name={aLabel} dataKey="a" stroke="var(--saffron)" fill="var(--saffron)" fillOpacity={0.18} strokeWidth={2} isAnimationActive animationDuration={400} />
          {b && <Radar name={bLabel} dataKey="b" stroke="var(--primary)" fill="var(--primary)" fillOpacity={0.22} strokeWidth={2} animationDuration={400} />}
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v}/10`} />
          {b && <Legend wrapperStyle={{ fontSize: 12, color: "var(--muted-foreground)" }} />}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ParetoChart({ data, front, recommended, onPick, selected }: {
  data: Candidate[]; front: Set<string>; recommended?: string; onPick?: (id: string) => void; selected?: string;
}) {
  const frontPts = data.filter((d) => front.has(d.id)).sort((x, y) => x.taste - y.taste);
  return (
    <div className="h-[340px] w-full">
      <ResponsiveContainer>
        <ScatterChart margin={{ top: 20, right: 30, bottom: 30, left: 0 }}>
          <CartesianGrid stroke="var(--border)" strokeDasharray="3 5" />
          <XAxis type="number" dataKey="taste" name="Taste match" domain={[50, 100]} unit="%" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} stroke="var(--border)" label={{ value: "Taste match with original →", position: "insideBottom", offset: -18, fill: "var(--muted-foreground)", fontSize: 11 }} />
          <YAxis type="number" dataKey="health" name="Nutrition score" domain={[0, 100]} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} stroke="var(--border)" label={{ value: "Nutrition score ↑", angle: -90, position: "insideLeft", offset: 18, fill: "var(--muted-foreground)", fontSize: 11 }} />
          <ZAxis range={[160, 160]} />
          <Tooltip contentStyle={tooltipStyle} cursor={{ stroke: "var(--sage)" }} formatter={(v: number, n: string) => [v, n]} labelFormatter={() => ""} />
          <Scatter data={frontPts} line={{ stroke: "var(--primary)", strokeDasharray: "4 4", strokeOpacity: 0.6 }} shape={() => <g />} isAnimationActive={false} />
          <Scatter data={data} onClick={(p: { id?: string; payload?: Candidate }) => onPick?.(p.payload?.id ?? p.id ?? "")} className="cursor-pointer">
            {data.map((d) => (
              <Cell
                key={d.id}
                fill={d.original ? "var(--saffron)" : front.has(d.id) ? "var(--primary)" : "var(--sage)"}
                stroke={d.id === recommended || d.id === selected ? "var(--foreground)" : "transparent"}
                strokeWidth={d.id === recommended ? 3 : 2}
              />
            ))}
            <LabelList dataKey="name" position="top" offset={12} style={{ fill: "var(--foreground)", fontSize: 11 }} />
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ScoreRing({ value, label, tone = "lime", size = 84 }: { value: number; label: string; tone?: "lime" | "saffron"; size?: number }) {
  const r = 34, c = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center gap-1">
      <svg viewBox="0 0 80 80" width={size} height={size} role="img" aria-label={`${label}: ${value}`}>
        <circle cx="40" cy="40" r={r} fill="none" stroke="var(--border)" strokeWidth="6" />
        <circle
          cx="40" cy="40" r={r} fill="none"
          stroke={tone === "lime" ? "var(--primary)" : "var(--saffron)"}
          strokeWidth="6" strokeLinecap="round" strokeDasharray={c}
          strokeDashoffset={c * (1 - value / 100)} transform="rotate(-90 40 40)"
          style={{ transition: "stroke-dashoffset .7s cubic-bezier(.2,.7,.2,1)" }}
        />
        <text x="40" y="46" textAnchor="middle" fill="var(--foreground)" fontSize="20" fontWeight="700">{value}</text>
      </svg>
      <span className="eyebrow text-center">{label}</span>
    </div>
  );
}
