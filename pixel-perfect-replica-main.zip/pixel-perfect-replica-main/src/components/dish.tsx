import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { DISH_IMAGES } from "@/lib/images";
import { nutritionOf, flavorOf } from "@/lib/flavor/engine";
import { DIMS, DIM_LABEL, type Recipe } from "@/lib/flavor/types";
import { actions, useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export function DishImage({ id, name, className, eager }: { id: string; name: string; className?: string; eager?: boolean }) {
  const src = DISH_IMAGES[id];
  if (!src) {
    return (
      <div className={cn("relative flex items-center justify-center overflow-hidden bg-surface-2", className)} role="img" aria-label={`${name} (no photo yet)`}>
        <svg viewBox="0 0 200 150" className="absolute inset-0 h-full w-full opacity-40" aria-hidden>
          <circle cx="100" cy="75" r="52" fill="none" stroke="var(--sage)" strokeDasharray="2 4" />
          <circle cx="100" cy="75" r="34" fill="none" stroke="var(--primary)" strokeOpacity=".5" />
          <path d="M70 90 C70 62 86 48 118 48 C118 74 102 90 70 90Z" fill="var(--primary)" fillOpacity=".25" />
        </svg>
        <span className="font-display relative px-4 text-center text-lg italic text-foreground/80">{name}</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={name}
      width={944}
      height={704}
      loading={eager ? "eager" : "lazy"}
      className={cn("object-cover", className)}
    />
  );
}

export function SaveButton({ id, name, className }: { id: string; name: string; className?: string }) {
  const { saved } = useAppState();
  const on = saved.includes(id);
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? `Remove ${name} from cravings` : `Save ${name} to cravings`}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        actions.toggleSave(id);
        toast(on ? `${name} removed from your cravings` : `${name} saved to your cravings`);
      }}
      className={cn(
        "glass flex h-9 w-9 items-center justify-center rounded-full transition-transform hover:scale-105 active:scale-95",
        className,
      )}
    >
      <Heart className={cn("h-4 w-4", on ? "fill-primary text-primary" : "text-foreground")} />
    </button>
  );
}

export function topNotes(r: Recipe, n = 3) {
  const f = flavorOf(r.items);
  return [...DIMS].sort((a, b) => f[b] - f[a]).slice(0, n).map((d) => DIM_LABEL[d].split(" ")[0]);
}

export function DishCard({ recipe }: { recipe: Recipe }) {
  const n = nutritionOf(recipe.items);
  return (
    <Link
      to="/dish/$id"
      params={{ id: recipe.id }}
      className="group panel relative flex flex-col overflow-hidden transition-colors hover:border-sage"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <DishImage id={recipe.id} name={recipe.name} className="h-full w-full transition-transform duration-700 group-hover:scale-105" />
        <div className="photo-shade absolute inset-0" />
        <SaveButton id={recipe.id} name={recipe.name} className="absolute right-3 top-3" />
        {recipe.kind === "twin" && <span className="tag-lime absolute left-3 top-3">Flavor twin</span>}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-baseline justify-between gap-2">
          <h3 className="font-display text-xl">{recipe.name}</h3>
          <span className="font-mono text-xs text-muted-foreground">{n.kcal} kcal</span>
        </div>
        <p className="line-clamp-2 text-sm text-muted-foreground">{recipe.blurb}</p>
        <div className="mt-auto flex flex-wrap gap-1.5 pt-2">
          {topNotes(recipe).map((t) => (
            <span key={t} className="tag-muted">{t}</span>
          ))}
          <span className="tag-saffron ml-auto">{n.protein} g protein</span>
        </div>
      </div>
    </Link>
  );
}
