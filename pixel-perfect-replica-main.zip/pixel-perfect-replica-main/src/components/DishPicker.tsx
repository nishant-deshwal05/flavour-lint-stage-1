import { CRAVINGS } from "@/lib/flavor/data";

export function DishPicker({ value, onChange, label = "Base recipe" }: { value: string; onChange: (id: string) => void; label?: string }) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="eyebrow">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-full border bg-surface px-3 py-1.5 text-sm text-foreground"
      >
        {CRAVINGS.map((r) => (
          <option key={r.id} value={r.id}>{r.name}</option>
        ))}
      </select>
    </label>
  );
}
