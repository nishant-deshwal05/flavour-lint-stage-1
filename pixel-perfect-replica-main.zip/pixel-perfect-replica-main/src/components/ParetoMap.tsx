import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ParetoChart } from "./charts";
import { Slider } from "@/components/ui/slider";
import { RECIPE } from "@/lib/flavor/data";
import { ALL_PRIORITIES, PRIORITY_LABEL, candidatesFor, paretoFront, recommend, subScores, nutritionOf, type Priority } from "@/lib/flavor/engine";
import { actions, useAppState } from "@/lib/store";

export function ParetoMap({ cravingId }: { cravingId: string }) {
  const { prefs, experiments } = useAppState();
  const priorities = prefs.priorities;
  const [weight, setWeight] = useState(55);
  const [picked, setPicked] = useState<string | undefined>();

  const extra = experiments.filter((e) => e.baseId === cravingId).slice(0, 3).map((e) => ({ id: e.id, name: e.name, items: e.items }));
  const data = useMemo(() => candidatesFor(cravingId, priorities, extra), [cravingId, priorities, extra.length]); // eslint-disable-line react-hooks/exhaustive-deps
  const front = useMemo(() => paretoFront(data), [data]);
  const rec = recommend(data, weight / 100);
  const ranked = [...data].sort((a, b) => (weight / 100) * (b.taste - a.taste) + (1 - weight / 100) * (b.health - a.health));
  const sel = data.find((d) => d.id === (picked ?? rec?.id));
  const selRecipe = sel ? RECIPE[sel.id] : undefined;

  const toggle = (p: Priority) => {
    const next = priorities.includes(p) ? priorities.filter((x) => x !== p) : [...priorities, p];
    if (next.length) actions.setPrefs({ priorities: next });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
      <div className="panel p-4">
        <ParetoChart data={data} front={front} recommended={rec?.id} selected={picked} onPick={setPicked} />
        <div className="flex flex-wrap gap-4 px-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-saffron" /> Original</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-primary" /> Best trade-off (not beaten on both)</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-sage" /> Beaten by another option</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full border-2 border-foreground" /> Recommended for your balance</span>
        </div>
      </div>
      <div className="space-y-5">
        <div className="panel p-5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-primary">Nutrition</span>
            <span className="eyebrow">Taste–Health balance</span>
            <span className="text-saffron">Taste</span>
          </div>
          <Slider value={[weight]} onValueChange={([v]) => setWeight(v)} min={0} max={100} step={5} className="mt-4" aria-label="Taste versus nutrition weight" />
          <p className="mt-3 text-xs text-muted-foreground">{weight}% taste · {100 - weight}% nutrition. Ranking = weighted sum of both scores.</p>
          <ol className="mt-4 space-y-1.5">
            {ranked.map((c, i) => (
              <li key={c.id}>
                <button onClick={() => setPicked(c.id)} className="flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left text-sm transition-colors hover:bg-muted data-[on=true]:bg-muted" data-on={sel?.id === c.id}>
                  <span className="font-mono text-xs text-muted-foreground">{i + 1}</span>
                  <span className="flex-1 truncate">{c.name}</span>
                  {front.has(c.id) && <span className="tag-lime">trade-off</span>}
                  <span className="font-mono text-xs text-muted-foreground">{c.taste}/{c.health}</span>
                </button>
              </li>
            ))}
          </ol>
        </div>
        <div className="panel p-5">
          <p className="eyebrow mb-3">What matters to you</p>
          <div className="flex flex-wrap gap-2">
            {ALL_PRIORITIES.map((p) => (
              <button key={p} className="chip" data-active={priorities.includes(p)} onClick={() => toggle(p)} aria-pressed={priorities.includes(p)}>{PRIORITY_LABEL[p]}</button>
            ))}
          </div>
          {sel && (
            <div className="mt-4 border-t pt-4 text-sm">
              <p className="font-display text-lg">{sel.name}</p>
              <p className="text-xs text-muted-foreground">Taste match {sel.taste}% · nutrition score {sel.health}/100</p>
              {selRecipe && (
                <ul className="mt-2 grid grid-cols-2 gap-1 text-xs text-muted-foreground">
                  {priorities.map((p) => <li key={p}>{PRIORITY_LABEL[p]}: <span className="text-foreground">{Math.round(subScores(nutritionOf(selRecipe.items))[p])}</span></li>)}
                </ul>
              )}
              {selRecipe && !sel.original && <Link to="/dish/$id" params={{ id: sel.id }} className="btn-line mt-3 !py-1.5 !text-xs">Open this twin</Link>}
            </div>
          )}
          <p className="mt-4 text-xs text-muted-foreground">No option is "healthiest for everyone" — the score only reflects the priorities you picked.</p>
        </div>
      </div>
    </div>
  );
}
