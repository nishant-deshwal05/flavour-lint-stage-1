import type { ReactNode } from "react";

export function SectionHead({ eyebrow, title, action }: { eyebrow: string; title: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="font-display mt-1.5 text-3xl">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function PageHead({ eyebrow, title, sub, action }: { eyebrow: string; title: ReactNode; sub?: ReactNode; action?: ReactNode }) {
  return (
    <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="font-display mt-2 text-4xl leading-tight sm:text-5xl">{title}</h1>
        {sub && <p className="mt-3 text-muted-foreground">{sub}</p>}
      </div>
      {action}
    </header>
  );
}
