import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Check, Lightbulb, AlertTriangle, Undo2, Wine } from "lucide-react";
import { toast } from "sonner";
import { ING, PAIRINGS } from "@/lib/flavor/data";
import { applyFix, flavorOf, healthScore, lint, matchScore, nutritionOf } from "@/lib/flavor/engine";
import type { Nutrition, RecipeItem } from "@/lib/flavor/types";
import { cn } from "@/lib/utils";

const ROWS: { k: keyof Nutrition; label: string; unit: string; better: "down" | "up" }[] = [
  { k: "kcal", label: "Energy", unit: "kcal", better: "down" },
  { k: "protein", label: "Protein", unit: "g", better: "up" },
  { k: "fat", label: "Fat", unit: "g", better: "down" },
  { k: "satFat", label: "Saturated fat", unit: "g", better: "down" },
  { k: "carbs", label: "Carbs", unit: "g", better: "down" },
  { k: "fiber", label: "Fibre", unit: "g", better: "up" },
  { k: "sodium", label: "Sodium", unit: "mg", better: "down" },
];

export function NutritionDiff({ a, b, aLabel, bLabel }: { a: Nutrition; b: Nutrition; aLabel: string; bLabel: string }) {
  return (
    <div className="overflow-hidden rounded-lg border">
      <table className="w-full text-sm">
        <thead className="bg-muted/50 text-left">
          <tr>
            <th className="px-3 py-2 font-medium text-muted-foreground">Per serving <span className="tag-saffron ml-1">estimate</span></th>
            <th className="px-3 py-2 text-right font-medium text-saffron">{aLabel}</th>
            <th className="px-3 py-2 text-right font-medium text-primary">{bLabel}</th>
            <th className="px-3 py-2 text-right font-medium text-muted-foreground">Δ</th>
          </tr>
        </thead>
        <tbody>
          {ROWS.map((r) => {
            const d = Math.round((b[r.k] - a[r.k]) * 10) / 10;
            const good = d === 0 ? null : (d < 0) === (r.better === "down");
            return (
              <tr key={r.k} className="border-t">
                <td className="px-3 py-2 text-muted-foreground">{r.label}</td>
                <td className="px-3 py-2 text-right font-mono">{a[r.k]}</td>
                <td className="px-3 py-2 text-right font-mono">{b[r.k]}</td>
                <td className={cn("px-3 py-2 text-right font-mono", good === null ? "text-muted-foreground" : good ? "text-primary" : "text-saffron")}>
                  <span className="inline-flex items-center gap-0.5">
                    {d > 0 ? <ArrowUp className="h-3 w-3" /> : d < 0 ? <ArrowDown className="h-3 w-3" /> : null}
                    {Math.abs(d)} {r.unit}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/** Recipe Linter — code-editor styled diagnostic report with Apply / Undo. */
export function RecipeLinter({ recipeId, name, baseItems }: { recipeId: string; name: string; baseItems: RecipeItem[] }) {
  const [stack, setStack] = useState<RecipeItem[][]>([baseItems]);
  const items = stack[stack.length - 1];
  const findings = useMemo(() => lint(items), [items]);
  const base = useMemo(() => ({ f: flavorOf(baseItems), n: nutritionOf(baseItems) }), [baseItems]);
  const cur = { f: flavorOf(items), n: nutritionOf(items) };
  const issues = findings.filter((f) => f.severity === "issue");
  const sugg = findings.filter((f) => f.severity === "suggestion");
  const pairings = PAIRINGS[recipeId] ?? [];

  const apply = (id: string) => {
    const fnd = findings.find((f) => f.id === id);
    if (!fnd?.fix) return;
    setStack((s) => [...s, applyFix(items, fnd.fix!)]);
    toast.success(`Applied: ${fnd.fixLabel}`);
  };

  return (
    <div className="overflow-hidden rounded-xl border bg-sidebar font-mono text-[0.8rem]">
      <div className="flex flex-wrap items-center gap-3 border-b px-4 py-2.5">
        <span className="flex gap-1.5" aria-hidden>
          <span className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-saffron/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-primary/70" />
        </span>
        <span className="text-muted-foreground">flavorlint ./{recipeId}.recipe</span>
        <span className="ml-auto flex items-center gap-3">
          <span className="text-destructive">{issues.length} issues</span>
          <span className="text-saffron">{sugg.length} suggestions</span>
          <button className="btn-line !py-1 !text-xs" disabled={stack.length < 2} onClick={() => setStack((s) => s.slice(0, -1))}>
            <Undo2 className="h-3 w-3" /> Undo
          </button>
        </span>
      </div>

      <div className="grid gap-px bg-border md:grid-cols-3">
        {[
          ["Taste match", `${matchScore(base.f, cur.f)}%`],
          ["Nutrition score", `${healthScore(base.n)} → ${healthScore(cur.n)}`],
          ["Energy", `${base.n.kcal} → ${cur.n.kcal} kcal`],
        ].map(([k, v]) => (
          <div key={k} className="bg-sidebar px-4 py-3">
            <div className="text-muted-foreground">{k}</div>
            <div className="mt-1 text-base text-foreground">{v}</div>
          </div>
        ))}
      </div>

      <ul className="divide-y">
        {findings.length === 0 && (
          <li className="flex items-center gap-2 px-4 py-5 text-primary">
            <Check className="h-4 w-4" /> No issues detected. {name} looks balanced by these rules.
          </li>
        )}
        {findings.map((f, i) => (
          <li key={f.id} className="grid grid-cols-[2rem_1fr] gap-x-2 px-4 py-3.5 animate-rise">
            <span className="text-muted-foreground/60">{String(i + 1).padStart(2, "0")}</span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                {f.severity === "issue" ? (
                  <span className="inline-flex items-center gap-1 text-destructive"><AlertTriangle className="h-3.5 w-3.5" /> issue</span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-saffron"><Lightbulb className="h-3.5 w-3.5" /> suggestion</span>
                )}
                <span className="text-sage">[{f.category}]</span>
                <span className="font-sans text-sm text-foreground">{f.title}</span>
              </div>
              <p className="mt-1 font-sans text-sm text-muted-foreground">{f.why}</p>
              {f.fix && (
                <button className="btn-lime mt-2.5 !px-3 !py-1.5 !text-xs" onClick={() => apply(f.id)}>
                  Apply fix · {f.fixLabel}
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>

      <div className="border-t px-4 py-3">
        <div className="mb-2 flex items-center gap-2 text-muted-foreground"><Wine className="h-3.5 w-3.5" /> drink pairing <span className="tag-muted">curated demo</span></div>
        {pairings.length ? (
          <ul className="space-y-1 font-sans text-sm">
            {pairings.map((p) => (
              <li key={p.name}><span className="text-foreground">{p.name}</span> <span className="text-muted-foreground">— {p.note}</span></li>
            ))}
          </ul>
        ) : (
          <p className="font-sans text-sm text-muted-foreground">No pairing data for this dish yet.</p>
        )}
      </div>
      {stack.length > 1 && (
        <div className="border-t px-4 py-3 font-sans text-xs text-muted-foreground">
          Current recipe: {items.map((i) => `${ING[i.ing]?.name} ${i.grams} g`).join(" · ")}
        </div>
      )}
    </div>
  );
}
