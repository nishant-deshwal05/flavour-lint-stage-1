import { Link, useRouterState } from "@tanstack/react-router";
import { Compass, Dna, FlaskConical, Heart, Home, UserRound } from "lucide-react";
import type { ReactNode } from "react";
import { Wordmark, LogoMark } from "./brand";
import { DATA_SOURCE } from "@/lib/flavor/data";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/cravings", label: "My Cravings", icon: Heart },
  { to: "/lab", label: "Mutation Lab", icon: FlaskConical },
  { to: "/dna", label: "Flavor DNA", icon: Dna },
  { to: "/profile", label: "Profile", icon: UserRound },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const active = (to: string) => (to === "/" ? path === "/" : path.startsWith(to));

  return (
    <div className="grain min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-sidebar-border bg-sidebar px-5 py-7 lg:flex">
        <Link to="/" aria-label="FlavorLint home">
          <Wordmark />
        </Link>
        <nav className="mt-10 flex flex-col gap-1" aria-label="Main">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground data-[on=true]:bg-sidebar-accent data-[on=true]:text-foreground"
              data-on={active(n.to)}
            >
              <n.icon className="h-4 w-4 transition-colors group-data-[on=true]:text-primary" />
              {n.label}
              {active(n.to) && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" />}
            </Link>
          ))}
        </nav>
        <div className="mt-auto rounded-lg border border-sidebar-border p-3">
          <p className="eyebrow">Data source</p>
          <p className="mt-1.5 text-xs text-muted-foreground">
            <span className="tag-saffron mb-1.5">Demo data</span>
            <br />
            {DATA_SOURCE.label}. External food databases aren't connected.
          </p>
        </div>
      </aside>

      <header className="glass sticky top-0 z-40 flex items-center justify-between border-x-0 border-t-0 px-4 py-3 lg:hidden">
        <Link to="/" aria-label="FlavorLint home" className="flex items-center gap-2">
          <LogoMark />
          <span className="font-display text-lg">
            Flavor<span className="italic text-primary">Lint</span>
          </span>
        </Link>
        <span className="tag-saffron">Demo data</span>
      </header>

      <main className="pb-24 lg:pb-0 lg:pl-64">
        <div key={path} className="animate-rise mx-auto max-w-[1280px] px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
          {children}
        </div>
      </main>

      <nav className="glass fixed inset-x-2 bottom-2 z-40 grid grid-cols-6 rounded-2xl p-1 lg:hidden" aria-label="Main">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            data-on={active(n.to)}
            className="flex flex-col items-center gap-1 rounded-xl py-2 text-[0.6rem] text-muted-foreground data-[on=true]:bg-accent data-[on=true]:text-primary"
          >
            <n.icon className="h-4 w-4" />
            <span className="truncate">{n.label.replace("My ", "").replace("Mutation ", "")}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
